# Landing page model
A landing page for a fake company
